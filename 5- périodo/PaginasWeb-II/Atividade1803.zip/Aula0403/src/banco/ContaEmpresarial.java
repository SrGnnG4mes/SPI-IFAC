package banco;

public class ContaEmpresarial extends Conta{
    public double totalInvestido;

    public ContaEmpresarial(int numero, String dono) {
        super(numero, dono);
        this.limite = 1200;
        this.tipo = "Empresarial";

        // Requisito 3: Investimento automático de 10 reais
        this.realizarInvestimento(10.0);
    }

    public void realizarInvestimento(double valor) {
        if (valor > 0) {
            this.totalInvestido += valor;
        }
    }
}
}

package banco;

public class ContaBlack extends Conta{
    public boolean temCartaoCredito;
    public double totalInvestido;

    public ContaBlack(int numero, String dono) {
        super(numero, dono);
        this.limite = 10000.00;
        this.temCartaoCredito = true;
        this.tipo = "Black";

        this.realizarInvestimento(10.0);
    }
    public void realizarInvestimento(double valor) {
        if (valor > 0) {
            this.totalInvestido += valor;
        }
    }
}

